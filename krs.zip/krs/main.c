
#include "task1.h"
#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    for(int i = 0; i < sizeof(tasks)/sizeof(*tasks); ++i){
        printf("task%d started\n", i+1);
        tasks[i]();
        printf("task%d stopped\n", i+1);
    }
    return 0;
}
