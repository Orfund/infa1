
#include "task1.h"
#include <math.h>


static int powi (int n, int deg){
    int res = 1;
    for(int i = 0; i < deg; ++i){
        res *= n;
    }
    return res;
}

int getDigit(int digitNo, int number){
    return (number / powi(10, digitNo)) % 10;
}
int task1(int a, int b){
    for(int i = a; i <= b; ++i){
        int res = 1;
        for(int digitNo = 0; digitNo < log10(i); digitNo++){
            int digit = getDigit(digitNo, i);
            if( digit )
                res &= !(i % digit);
        }
        if(res)
            printf("%d\n", i);
        
    }
    return 0;
}

int task1Wrapper(){
    FILE * f = fopen("in1.txt", "r");
    int a, b;
    fscanf(f, "%d%d", &a, &b);
    task1(a, b);
    fclose(f);
    return 0;
}

int checkEquality(int* arr_first, int arr_length, int n){
    for(int i = 0; i < arr_length && i < 4; ++i){
        if(n == arr_first[i])
            return i;
    }
    return -1;
}
int task2(FILE*fin){
    int arr_first[4];
    int arr_l = 0;
    int cur;
    while(fscanf(fin, "%d", &cur) == 1){
        int equality = checkEquality(arr_first, arr_l, cur);
        if( equality==-1  && arr_l < 4){
            arr_first[arr_l] = cur;
            arr_l++;
        }
    }
    return arr_l;
    
}
int task2Wrapper(void){
    FILE * f = fopen("in2.txt", "r");
    int res = task2(f);
    printf("%d different values\n", res);
    fclose(f);
    return 0;
}

int task3(FILE*fin){
    int mainbuf = 0;
    int ubufused = 0;
    int mbufused = 0;
    int cur;
    while( fscanf(fin, "%d", &cur) == 1 ){
        if(!mbufused){
            mainbuf = cur;
            mbufused = 1;
        }
        if( cur != mainbuf ){
            if(!ubufused)
                ubufused = 1;
            else
                return 1;
        }
    }
    return 0;
}
int task3Wrapper(void){
    FILE * f = fopen("in3.txt", "r");
    int res = task3(f);
    if(res)
        printf("No\n");
    else
        printf("Yes\n");
    fclose(f);
    return 0;
}

int readArray(double **arrMemPtr, FILE*src){
    int amount = 0;
    double cur;
    while(fscanf(src, "%lf", &cur)==1){
        amount++;
    }
    rewind(src);
    (*arrMemPtr) = (double*)malloc(sizeof(double)*amount);
    for(int i = 0; i < amount; ++i){
        fscanf(src, "%lf", &cur);
        (*arrMemPtr)[i] = cur;
    }
    return amount;
}
void printArray(double*arr, int length, FILE*out){
    for(int i = 0; i < length; ++i)
        fprintf(out, "%lf ", arr[i]);
}

double mean(double*arr, int l){
    double sum = 0;
    for(int i = 0; i < l; ++i){
        sum += arr[i];
    }
    return sum / l;
}


int task4Wrapper(void){
    int length;
    double * arr;
    FILE * fin = fopen("in4.txt","r");
    length = readArray(&arr, fin);
    int bound = 0;
    for(int i = 0; i < length - 1; ++i){
        if(arr[i+1] > arr[i]){
            bound = i;
            while(arr[i+1] > arr[i] && i < length - 1){
                i++;
            }
            i++;
            if(bound != i - 1){
                double m = mean(arr+bound, i-bound);
                for(int j = bound; j < i; ++j){
                    arr[j] = m;
                }
                i--;
            }
        }
        
        
    }
    fclose(fin);
    FILE * fout = fopen("out4.txt", "w");
    printArray(arr, length, fout);
    fclose(fout);
    return 0;
}
