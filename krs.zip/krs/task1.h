

#ifndef task1_h
#define task1_h

#include <stdio.h>
#include <stdlib.h>

typedef int(*taskExecutor)(void);



//-------

int getDigit(int, int);
int task1(int, int);
int task1Wrapper(void);

//--------

int checkEquality(int*, int, int);
int task2(FILE*);
int task2Wrapper(void);
//--------


int task3(FILE*);
int task3Wrapper(void);

//--------
int readArray(double **, FILE*);
void printArray(double*, int, FILE*);
double mean(double*, int);
int detectInterval(double*, int, double**);
int replaceInterval(double*, int, int);
int task4Wrapper(void);

//--------

static taskExecutor tasks[] = {
    &task1Wrapper,
    &task2Wrapper,
    &task3Wrapper,
    &task4Wrapper
};


#endif /* task1_h */
